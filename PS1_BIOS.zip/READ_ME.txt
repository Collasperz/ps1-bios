To check hashes, and for more information, see:
http://emulation.gametechwiki.com/index.php/File_Hashes#PlayStation_1_BIOS

Mednafen/Beetle PSX needs:
ps-30j.bin	renamed to	scph5500.bin
ps-30a.bin	renamed to	scph5501.bin
ps-30e.bin	renamed to	scph5502.bin
and placed in the 'firmware' folder (for mednafen standalone), or System Directory (for RetroArch).

ePSXe and PCSX-Reloaded recommend ps-22a.bin

Xebra needs a BIOS file to be renamed to "OSROM" - case sensitive, no file extension - ps-22a.bin or ps-30a.bin is recommended.